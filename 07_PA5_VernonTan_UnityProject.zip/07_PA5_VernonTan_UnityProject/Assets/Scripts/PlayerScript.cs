﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerScript : MonoBehaviour
{
    public float speed;
    Rigidbody PlayerRigidbody;

    public float coins;
    public Text score;

    // Start is called before the first frame update
    void Start()
    {
        PlayerRigidbody = gameObject.GetComponent<Rigidbody>();
    }

    private void Update()
    {
      
    }
    private void FixedUpdate()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");
        Vector3 movement = new Vector3(moveHorizontal, 0, moveVertical);
        PlayerRigidbody.AddForce(movement * speed * Time.deltaTime);
    }

    public void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject.tag == "Coin")
        {
            Destroy(collision.gameObject);
            coins += 1;
            score.text = "Coins collected : " + coins;
            if(coins == 4)
            {
                SceneManager.LoadScene("WinScreen");
            }
        }
        else if(collision.gameObject.tag == "Death")
        {
            SceneManager.LoadScene("LoseScreen");
        }
    }

    
}
